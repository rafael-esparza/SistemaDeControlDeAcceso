# Historial de cambios

## v1.0.0 - 2025-06-05
- Versión inicial del repositorio.